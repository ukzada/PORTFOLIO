# HTR-using-CRNN
## A school Project for Optical Character:wORDS Recogniton more oriented to handwritting recongnition done using Convolutional Recurrent Neural Networks(CRNN) using The IAM dataset
### I trained the model thanks to GoogleColab reached an accuracy of 99.99% 
### Model Accuracy
![](https://github.com/vulture990/OCR-using-CRNN/blob/main/accuracy.jpeg)
![](https://github.com/vulture990/OCR-using-CRNN/blob/main/plotgraph.png)
## The Model was able to spot some words like this :
![](https://github.com/vulture990/OCR-using-CRNN/blob/main/bound.png)

![](https://github.com/vulture990/OCR-using-CRNN/blob/main/demonstrations.png)

![](https://github.com/vulture990/OCR-using-CRNN/blob/main/want.png)

![](https://github.com/vulture990/OCR-using-CRNN/blob/main/discus.png)
## The Model also failed to recongnize some other tedious words like this:


![](https://github.com/vulture990/OCR-using-CRNN/blob/main/boycotting.png)

![](https://github.com/vulture990/OCR-using-CRNN/blob/main/nkmbula.png)

![](https://github.com/vulture990/OCR-using-CRNN/blob/main/Roy.png)


